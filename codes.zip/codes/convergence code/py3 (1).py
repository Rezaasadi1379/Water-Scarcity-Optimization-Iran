#!/usr/bin/env python3
"""
Hypervolume + IGD convergence figure for every scenario.

Reads all files named  Pareto_Gen_<generation>_S<scenario>.csv  in INPUT_FOLDER
(sub-folders are searched too) and saves, for each scenario, a two-panel figure:
  (a) hypervolume vs generation (labels = % of the final value)
  (b) IGD to the final front vs generation
plus one overview figure with all scenarios (top row HV, bottom row IGD).

Objectives: minimise cost, maximise TW, maximise LRW.
Requirements: numpy, pandas, matplotlib   (pip install numpy pandas matplotlib)
"""
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ============================================================================
# >>>>>>>>>>>>>>>>>>>>>>>  ENTER YOUR PATHS HERE  <<<<<<<<<<<<<<<<<<<<<<<<<<<
# ============================================================================
INPUT_FOLDER = r"C:\Users\Asus\Desktop\convergence\ParetoCSV_S8_20261023_092102\ParetoCSV_S8_20261023_092102"   # folder with the csv files
OUTPUT_FOLDER = None     # None -> "convergence_figures" inside INPUT_FOLDER
# ============================================================================

COST_COL, TW_COL, LRW_COL = "Cost_TB_Rials", "TotalWater_M_m3", "LowRisk_M_m3"
COST_DIVISOR = 1000.0      # file unit -> thousand billion rials
REF_POINT = 1.1            # hypervolume reference point (normalised space)
DPI = 300
plt.rcParams.update({"font.size": 10, "font.family": "serif"})


def load_snapshots(folder):
    pat = re.compile(r"Pareto_Gen_(\d+)_S(\d+)\.csv$", re.IGNORECASE)
    data = {}
    for f in sorted(Path(folder).rglob("*.csv")):
        m = pat.search(f.name)
        if not m:
            continue
        gen, scen = int(m.group(1)), int(m.group(2))
        df = pd.read_csv(f).rename(columns=lambda c: c.strip())
        d = pd.DataFrame({"Cost": df[COST_COL] / COST_DIVISOR,
                          "TW": df[TW_COL], "LRW": df[LRW_COL]})
        data.setdefault(scen, {})[gen] = d
    return data


def to_min(df):
    return np.column_stack([df["Cost"], -df["TW"], -df["LRW"]])


def nondominated(P):
    P = np.asarray(P)
    keep = np.ones(len(P), dtype=bool)
    for i in range(len(P)):
        if keep[i] and (np.all(P <= P[i], axis=1) & np.any(P < P[i], axis=1)).any():
            keep[i] = False
    _, idx = np.unique(P, axis=0, return_index=True)
    dup = np.ones(len(P), dtype=bool)
    dup[idx] = False
    return keep & ~dup


def hv2d(P, ref):
    if len(P) == 0:
        return 0.0
    P = P[np.argsort(P[:, 0])]
    hv, best_y = 0.0, ref[1]
    for x, y in P:
        if y < best_y:
            hv += (ref[0] - x) * (best_y - y)
            best_y = y
    return hv


def hv3d(P, ref):
    P = P[np.all(P < ref, axis=1)]
    if len(P) == 0:
        return 0.0
    P = P[np.argsort(P[:, 2])]
    zs = list(P[:, 2]) + [ref[2]]
    hv = 0.0
    for i in range(len(P)):
        dz = zs[i + 1] - zs[i]
        if dz > 0:
            hv += hv2d(P[: i + 1, :2], ref[:2]) * dz
    return hv


def igd(front, ref_front):
    d = np.sqrt(((ref_front[:, None, :] - front[None, :, :]) ** 2).sum(axis=2))
    return d.min(axis=1).mean()


def metrics(snaps):
    gens = sorted(snaps)
    allP = np.vstack([to_min(d) for d in snaps.values()])
    lo, hi = allP.min(axis=0), allP.max(axis=0)
    span = np.where(hi - lo == 0, 1, hi - lo)
    ref = np.full(3, REF_POINT)
    norm = {g: (to_min(snaps[g]) - lo) / span for g in gens}
    final_nd = norm[gens[-1]][nondominated(norm[gens[-1]])]
    rows = []
    for g in gens:
        Pn = norm[g][nondominated(norm[g])]
        rows.append({"Generation": g, "Hypervolume": hv3d(Pn, ref),
                     "IGD": igd(Pn, final_nd)})
    m = pd.DataFrame(rows)
    m["HV_pct_final"] = 100 * m["Hypervolume"] / m["Hypervolume"].iloc[-1]
    m["HV_change_pct"] = 100 * m["Hypervolume"].pct_change().abs()
    return m


def draw_hv(ax, m, title):
    ax.plot(m["Generation"], m["Hypervolume"], "o-", color="#08519c", lw=2)
    for x, y, r in zip(m["Generation"], m["Hypervolume"], m["HV_pct_final"]):
        ax.annotate(f"{r:.1f}%", (x, y), textcoords="offset points",
                    xytext=(0, -14), ha="center", fontsize=7)
    ax.set_xlabel("Generation"); ax.set_ylabel("Hypervolume (normalised)")
    ax.set_title(title); ax.grid(alpha=.3)


def draw_igd(ax, m, title):
    ax.plot(m["Generation"], m["IGD"], "s-", color="#6a3d9a", lw=2)
    ax.set_xlabel("Generation"); ax.set_ylabel("IGD to final front (normalised)")
    ax.set_title(title); ax.grid(alpha=.3)


def save(fig, out, name):
    fig.savefig(out / f"{name}.png", dpi=DPI)
    fig.savefig(out / f"{name}.pdf")
    plt.close(fig)


def main():
    folder = Path(INPUT_FOLDER)
    out = Path(OUTPUT_FOLDER) if OUTPUT_FOLDER else folder / "convergence_figures"
    if not folder.is_dir():
        sys.exit(f"Input folder not found: {folder}\nCheck INPUT_FOLDER at the top.")
    out.mkdir(parents=True, exist_ok=True)

    data = load_snapshots(folder)
    if not data:
        sys.exit(f"No files named Pareto_Gen_<gen>_S<scenario>.csv found in:\n{folder}")

    allm = {}
    for s, snaps in sorted(data.items()):
        if len(snaps) < 2:
            print(f"S{s}: fewer than 2 generations, skipped"); continue
        m = metrics(snaps); allm[s] = m
        fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
        draw_hv(ax[0], m, "(a) Hypervolume (labels: % of final value)")
        draw_igd(ax[1], m, "(b) Inverted generational distance")
        fig.suptitle(f"Convergence of NSGA-II, scenario S{s}")
        fig.tight_layout(); save(fig, out, f"S{s}_HV_IGD")
        print(f"S{s}: HV(last)/HV(previous) change = {m['HV_change_pct'].iloc[-1]:.2f}%")
        m.assign(Scenario=f"S{s}").to_csv(out / f"S{s}_HV_IGD_values.csv", index=False)

    if len(allm) > 1:      # overview of all scenarios
        n = len(allm)
        fig, ax = plt.subplots(2, n, figsize=(2.9 * n, 5.6), squeeze=False)
        for j, (s, m) in enumerate(sorted(allm.items())):
            draw_hv(ax[0, j], m, f"S{s}"); draw_igd(ax[1, j], m, "")
            ax[0, j].set_ylabel("Hypervolume" if j == 0 else "")
            ax[1, j].set_ylabel("IGD" if j == 0 else "")
            for t in ax[0, j].texts:
                t.set_visible(False)
        fig.suptitle("Hypervolume (top) and IGD (bottom), all scenarios")
        fig.tight_layout(); save(fig, out, "All_scenarios_HV_IGD")
    print(f"\nFigures saved in: {out.resolve()}")


if __name__ == "__main__":
    main()