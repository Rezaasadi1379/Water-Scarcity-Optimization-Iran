"""
Three-Objective Water Conservation Optimization - AUTO-MULTICORE VERSION (FIXED)
✓ Automatically detects and uses ALL available CPU cores
✓ Cross-platform (Windows/Linux/Mac)☻
✓ Fixed Windows multiprocessing issue
✓ CSV outputs for each generation's Pareto front
✓ Memory-efficient with user-defined snapshots
✓ User-defined INPUT_DIR / OUTPUT_DIR (see "USER PATHS" below)
✓ Vectorized (numpy) non-dominated sorting: same fronts as before, much faster
"""
import numpy as np
import pandas as pd
from deap import base, creator, tools
import random
import time
from datetime import datetime
from scipy.optimize import linprog
import os
import warnings
import matplotlib
matplotlib.use("Agg")   # figures are only saved to file, never shown
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import Normalize
from multiprocessing import Pool, cpu_count
import platform

warnings.filterwarnings('ignore')

# ============================================================================
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  USER PATHS  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# ============================================================================
# Folder that contains effectiveness.xlsx, volumes.xlsx and scenarios.xlsx
INPUT_DIR = r"D:\MOPI\input data & the code of the optimization\input data & the code of the optimization"

# Folder where ALL results are saved (CSV folder, PNG figure, final Excel folder)
OUTPUT_DIR = r"D:\MOPI\input data & the code of the optimization\results"
# ============================================================================
os.makedirs(OUTPUT_DIR, exist_ok=True)

random.seed(42)
np.random.seed(42)

_optimizer_instance = None

def _init_worker(optimizer):
    """Initialize worker process with optimizer instance"""
    global _optimizer_instance
    _optimizer_instance = optimizer

def _evaluate_individual_worker(individual):
    """Worker function for parallel evaluation"""
    return _optimizer_instance.evaluate_individual(individual)

class WaterOptimizerAutoCore:
    def __init__(self, scenario_to_run=1, population_size=9000, max_generations=200,
                 snapshot_generations=None):
        self.scenario_to_run = scenario_to_run
        self.POPULATION_SIZE = population_size
        self.MAX_GENERATIONS = max_generations

        # AUTO-DETECT CORES
        total_cores = cpu_count()
        self.N_CORES = max(1, total_cores - 1)

        # Default snapshot generations (unchanged)
        if snapshot_generations is None:
            self.SNAPSHOT_GENERATIONS = [0, 10, 20, 30, 40, 50, 60, 80, 100, 120, 140, 160, 180, 200]
            if max_generations not in self.SNAPSHOT_GENERATIONS:
                self.SNAPSHOT_GENERATIONS.append(max_generations)
        else:
            self.SNAPSHOT_GENERATIONS = sorted(set(snapshot_generations))
            # the last generation is always saved, so the final front has a CSV too
            if max_generations not in self.SNAPSHOT_GENERATIONS:
                self.SNAPSHOT_GENERATIONS.append(max_generations)

        self.scenario_names = {
            1: 'Budget 40% - Cost Scenario 1 (MARR=0.68)',
            2: 'Budget 40% - Cost Scenario 2 (MARR=0.8)',
            3: 'Budget 40% - Cost Scenario 3 (C=0.7Cmin)',
            4: 'Budget 40% - Cost Scenario 4 (C=2Cmax)',
            5: 'Budget 50% - Cost Scenario 1 (MARR=0.68)',
            6: 'Budget 50% - Cost Scenario 2 (MARR=0.8)',
            7: 'Budget 50% - Cost Scenario 3 (C=0.7Cmin)',
            8: 'Budget 50% - Cost Scenario 4 (C=2Cmax)'
        }

        self.CROSSOVER_PROB = 0.9
        self.MUTATION_PROB = 0.2
        self.ETA_C = 20
        self.ETA_M = 20

        self.num_provinces = 30
        self.num_projects = 10
        self.num_years = 6
        self.num_variables = self.num_provinces * self.num_projects * self.num_years

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.csv_output_dir = os.path.join(OUTPUT_DIR, f"ParetoCSV_S{scenario_to_run}_{timestamp}")
        os.makedirs(self.csv_output_dir, exist_ok=True)

        print(f"\n{'='*80}")
        print(f"SYSTEM & OPTIMIZATION CONFIGURATION")
        print(f"{'='*80}")
        print(f"Operating System: {platform.system()} {platform.release()}")
        print(f"Python Version: {platform.python_version()}")
        print(f"Total CPU Cores: {total_cores}")
        print(f"Cores to Use: {self.N_CORES} (reserved 1 for OS)")
        print(f"Expected Speedup: ~{self.N_CORES}x faster than single-core")
        print(f"---")
        print(f"Decision Variables: {self.num_variables}")
        print(f"Population: {self.POPULATION_SIZE} ({self.POPULATION_SIZE/self.num_variables:.1f}x variables)")
        print(f"Generations: {self.MAX_GENERATIONS}")
        print(f"Snapshot Generations: {self.SNAPSHOT_GENERATIONS}")
        print(f"Input Directory: {INPUT_DIR}")
        print(f"CSV Output Directory: {self.csv_output_dir}")
        print(f"{'='*80}\n")

        self.project_names = [
            'Orchard renovation', 'Transplantation', 'Conservation agriculture',
            'Controlled Environment Agriculture', 'Crop pattern modification',
            'Modern irrigation systems', 'Meter installation',
            'Water extraction license adjustment', 'Well form 1 determination',
            'Illegal well closure'
        ]

        self.low_risk_projects = [0, 1, 2, 3, 4, 5]
        self.total_water_projects = [6, 7, 8, 9]

        self.pareto_archive = []
        self.lp_anchor_points = []
        self.pareto_history = {}

        self.load_data_from_excel()
        self.solve_lp_anchor_points()

    def load_data_from_excel(self):
        print("="*80)
        print("LOADING DATA")
        print("="*80)
        try:
            eff_path = os.path.join(INPUT_DIR, 'effectiveness.xlsx')
            vol_path = os.path.join(INPUT_DIR, 'volumes.xlsx')
            scen_path = os.path.join(INPUT_DIR, 'scenarios.xlsx')
            for p in (eff_path, vol_path, scen_path):
                if not os.path.isfile(p):
                    raise FileNotFoundError(f"Input file not found: {p}\n"
                                            f"Check INPUT_DIR at the top of the script.")

            eff_df = pd.read_excel(eff_path, sheet_name='Sheet2', header=None)
            self.effectiveness = np.zeros((30, 10))
            for i in range(30):
                for j in range(10):
                    value = eff_df.iloc[i+1, j]
                    self.effectiveness[i, j] = float(value) if not pd.isna(value) else 0.0

            vol_df = pd.read_excel(vol_path, sheet_name='Sheet1', header=None)
            self.max_volumes = np.zeros((30, 10))
            for i in range(30):
                for j in range(10):
                    value = vol_df.iloc[i+1, j]
                    self.max_volumes[i, j] = float(value) if not pd.isna(value) else 0.0

            scen_df = pd.read_excel(scen_path, sheet_name='Sheet1', header=None)

            budget_row_index = 1 if self.scenario_to_run <= 4 else 2
            budget_row = scen_df.iloc[budget_row_index, 0:6].values[::-1]
            self.current_budget = budget_row

            scenarios_to_effectiveness = {
                5: 9, 6: 8, 7: 7, 8: 6, 9: 5,
                10: 4, 11: 2, 12: 3, 13: 1, 14: 0
            }

            cost_scenario = ((self.scenario_to_run - 1) % 4) + 1
            self.current_costs = np.zeros((10, 6))

            if cost_scenario == 1:
                for scenarios_row in range(5, 15):
                    eff_col = scenarios_to_effectiveness[scenarios_row]
                    for j in range(6):
                        value = scen_df.iloc[scenarios_row, j]
                        self.current_costs[eff_col, 5-j] = float(value) if not pd.isna(value) else 0.0
            elif cost_scenario == 2:
                for scenarios_row in range(5, 15):
                    eff_col = scenarios_to_effectiveness[scenarios_row]
                    for j in range(6):
                        value = scen_df.iloc[scenarios_row, j+8]
                        self.current_costs[eff_col, 5-j] = float(value) if not pd.isna(value) else 0.0
            elif cost_scenario == 3:
                for i, scenarios_row in enumerate(range(17, 27)):
                    eff_col = scenarios_to_effectiveness[i + 5]
                    for j in range(6):
                        value = scen_df.iloc[scenarios_row, j]
                        self.current_costs[eff_col, 5-j] = float(value) if not pd.isna(value) else 0.0
            else:
                for i, scenarios_row in enumerate(range(17, 27)):
                    eff_col = scenarios_to_effectiveness[i + 5]
                    for j in range(6):
                        value = scen_df.iloc[scenarios_row, j+8]
                        self.current_costs[eff_col, 5-j] = float(value) if not pd.isna(value) else 0.0

            print(f"✓ Scenario: {self.scenario_names[self.scenario_to_run]}")
            print(f"✓ Budget: {self.current_budget.sum()/1e6:.2f} TB rials")

            self.max_free_water = sum(self.effectiveness[i, j] * self.max_volumes[i, j]
                                      for i in range(30) for j in [7, 8])
            print(f"✓ Max free water: {self.max_free_water/1e6:.2f} M m³")
            print("="*80 + "\n")

        except Exception as e:
            print(f"ERROR: {str(e)}")
            import traceback
            traceback.print_exc()
            raise

    def solve_lp_anchor_points(self):
        print("="*80)
        print("SOLVING LP ANCHOR POINTS")
        print("="*80)

        sol1 = self.solve_lp_min_cost()
        if sol1 is not None:
            self.lp_anchor_points.append(sol1)

        sol2 = self.solve_lp_max_total_water()
        if sol2 is not None:
            self.lp_anchor_points.append(sol2)

        sol3 = self.solve_lp_max_combined_water()
        if sol3 is not None:
            self.lp_anchor_points.append(sol3)

        print(f"✓ Generated {len(self.lp_anchor_points)} LP anchors")
        print("="*80 + "\n")

    def solve_lp_min_cost(self):
        n_vars = self.num_variables
        c = np.zeros(n_vars)
        var_idx = 0
        for i in range(self.num_provinces):
            for j in range(self.num_projects):
                for t in range(self.num_years):
                    c[var_idx] = self.current_costs[j, t]
                    var_idx += 1

        A_ub, b_ub = self.build_constraints_with_rollover(n_vars)

        min_water_constraint = np.zeros(n_vars)
        var_idx = 0
        for i in range(self.num_provinces):
            for j in range(self.num_projects):
                for t in range(self.num_years):
                    if j in self.total_water_projects:
                        min_water_constraint[var_idx] = -self.effectiveness[i, j]
                    var_idx += 1
        A_ub.append(min_water_constraint)
        b_ub.append(-0.5 * self.max_free_water)

        bounds = [(0, None) for _ in range(n_vars)]
        result = linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub), bounds=bounds,
                        method='highs', options={'disp': False})
        return result.x if result.success else None

    def solve_lp_max_total_water(self):
        n_vars = self.num_variables
        c = np.zeros(n_vars)
        var_idx = 0
        for i in range(self.num_provinces):
            for j in range(self.num_projects):
                for t in range(self.num_years):
                    if j in self.total_water_projects:
                        c[var_idx] = -self.effectiveness[i, j]
                    var_idx += 1

        A_ub, b_ub = self.build_constraints_with_rollover(n_vars)
        bounds = [(0, None) for _ in range(n_vars)]
        result = linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub), bounds=bounds,
                        method='highs', options={'disp': False})
        return result.x if result.success else None

    def solve_lp_max_combined_water(self):
        n_vars = self.num_variables
        c = np.zeros(n_vars)
        var_idx = 0
        for i in range(self.num_provinces):
            for j in range(self.num_projects):
                for t in range(self.num_years):
                    c[var_idx] = -self.effectiveness[i, j]
                    var_idx += 1

        A_ub, b_ub = self.build_constraints_with_rollover(n_vars)
        bounds = [(0, None) for _ in range(n_vars)]
        result = linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub), bounds=bounds,
                        method='highs', options={'disp': False})
        return result.x if result.success else None

    def build_constraints_with_rollover(self, n_vars):
        A_ub = []
        b_ub = []

        for t in range(self.num_years):
            constraint = np.zeros(n_vars)
            var_idx = 0
            for i in range(self.num_provinces):
                for j in range(self.num_projects):
                    for t2 in range(self.num_years):
                        if t2 <= t:
                            constraint[var_idx] = self.current_costs[j, t2]
                        var_idx += 1
            A_ub.append(constraint)
            b_ub.append(sum(self.current_budget[0:t+1]))

        for i in range(self.num_provinces):
            for j in range(self.num_projects):
                constraint = np.zeros(n_vars)
                var_idx = 0
                for i2 in range(self.num_provinces):
                    for j2 in range(self.num_projects):
                        for t in range(self.num_years):
                            if i2 == i and j2 == j:
                                constraint[var_idx] = 1.0
                            var_idx += 1
                A_ub.append(constraint)
                b_ub.append(self.max_volumes[i, j])

        for i in range(self.num_provinces):
            constraint = np.zeros(n_vars)
            var_idx = 0
            for i2 in range(self.num_provinces):
                for j in range(self.num_projects):
                    for t in range(self.num_years):
                        if i2 == i:
                            if j in self.total_water_projects:
                                constraint[var_idx] = -self.effectiveness[i, j]
                            elif j in self.low_risk_projects:
                                constraint[var_idx] = self.effectiveness[i, j]
                        var_idx += 1
            A_ub.append(constraint)
            b_ub.append(0.0)

        return A_ub, b_ub

    def calculate_violations(self, individual):
        x = np.array(individual).reshape((self.num_provinces, self.num_projects, self.num_years))
        total_violation = 0.0

        yearly_costs = np.einsum('jt,ijt->t', self.current_costs, x)
        cumulative_spent = np.cumsum(yearly_costs)
        cumulative_budget = np.cumsum(self.current_budget)
        budget_violations = np.maximum(0, cumulative_spent - cumulative_budget)
        total_violation += budget_violations.sum()

        total_volumes = x.sum(axis=2)
        capacity_violations = np.maximum(0, total_volumes - self.max_volumes)
        total_violation += capacity_violations.sum()

        for i in range(self.num_provinces):
            total_water = sum(self.effectiveness[i, j] * x[i, j, :].sum()
                             for j in self.total_water_projects)
            low_risk_water = sum(self.effectiveness[i, j] * x[i, j, :].sum()
                                for j in self.low_risk_projects)
            if total_water < low_risk_water:
                total_violation += (low_risk_water - total_water)

        return total_violation

    def evaluate_individual(self, individual):
        x = np.array(individual).reshape((self.num_provinces, self.num_projects, self.num_years))

        total_cost = np.einsum('jt,ijt->', self.current_costs, x)

        total_water_mask = np.zeros((self.num_provinces, self.num_projects))
        for j in self.total_water_projects:
            total_water_mask[:, j] = self.effectiveness[:, j]
        total_water_savings = np.einsum('ij,ijt->', total_water_mask, x)

        low_risk_mask = np.zeros((self.num_provinces, self.num_projects))
        for j in self.low_risk_projects:
            low_risk_mask[:, j] = self.effectiveness[:, j]
        low_risk_water_savings = np.einsum('ij,ijt->', low_risk_mask, x)

        violations = self.calculate_violations(individual)
        individual.constraint_violation = violations

        return (total_cost, -total_water_savings, -low_risk_water_savings)

    def repair_individual_gentle(self, individual):
        x = np.array(individual).reshape((self.num_provinces, self.num_projects, self.num_years))
        SAFETY_FACTOR = 0.95

        total_volumes = x.sum(axis=2)
        exceed_mask = total_volumes > self.max_volumes
        for i in range(self.num_provinces):
            for j in range(self.num_projects):
                if exceed_mask[i, j] and total_volumes[i, j] > 0:
                    scale = SAFETY_FACTOR * self.max_volumes[i, j] / total_volumes[i, j]
                    x[i, j, :] *= scale

        cumulative_spent = 0.0
        cumulative_budget = 0.0
        for t in range(self.num_years):
            year_cost = np.sum(self.current_costs[:, t] * x[:, :, t])
            cumulative_spent += year_cost
            cumulative_budget += self.current_budget[t]

            if cumulative_spent > cumulative_budget and cumulative_spent > 0:
                scale = SAFETY_FACTOR * (cumulative_budget - (cumulative_spent - year_cost)) / year_cost
                if scale > 0:
                    x[:, :, t] *= scale
                    cumulative_spent = sum(np.sum(self.current_costs[:, t2] * x[:, :, t2])
                                         for t2 in range(t+1))

        for i in range(self.num_provinces):
            total_water = sum(self.effectiveness[i, j] * x[i, j, :].sum()
                             for j in self.total_water_projects)
            low_risk_water = sum(self.effectiveness[i, j] * x[i, j, :].sum()
                                for j in self.low_risk_projects)

            if total_water < low_risk_water and low_risk_water > 0:
                scale = SAFETY_FACTOR * total_water / low_risk_water
                for j in self.low_risk_projects:
                    x[i, j, :] *= scale

        return x.flatten().tolist()

    def fast_non_dominated_sort(self, population):
        """Vectorized (numpy) non-dominated sorting.
        Returns exactly the same fronts, in the same order, as the original
        pure-Python version (same dominance rule, same ordering by cost),
        but is dramatically faster for large populations."""
        feasible = [ind for ind in population if ind.constraint_violation == 0]
        infeasible = [ind for ind in population if ind.constraint_violation > 0]

        if len(feasible) == 0:
            return [infeasible]

        feasible.sort(key=lambda x: x.fitness.values[0])

        F = np.array([ind.fitness.values for ind in feasible], dtype=float)
        n = len(feasible)

        # dom[j, i] = True if j dominates i (minimisation, same rule as dominates())
        all_le = np.ones((n, n), dtype=bool)
        any_lt = np.zeros((n, n), dtype=bool)
        for k in range(F.shape[1]):
            col = F[:, k]
            all_le &= (col[:, None] <= col[None, :])
            any_lt |= (col[:, None] < col[None, :])
        dom = all_le & any_lt
        del all_le, any_lt

        count = dom.sum(axis=0).astype(np.int64)   # number of points dominating i
        assigned = np.zeros(n, dtype=bool)
        fronts = []
        while not assigned.all():
            idx = np.flatnonzero((count == 0) & ~assigned)
            if len(idx) == 0:
                break
            fronts.append([feasible[i] for i in idx])
            assigned[idx] = True
            count -= dom[idx, :].sum(axis=0)

        if len(infeasible) > 0:
            fronts.append(infeasible)

        return fronts

    def dominates(self, ind1, ind2):
        f1 = ind1.fitness.values
        f2 = ind2.fitness.values

        better = False
        for i in range(len(f1)):
            if f1[i] > f2[i]:
                return False
            elif f1[i] < f2[i]:
                better = True

        return better

    def calculate_crowding_distance(self, front):
        if len(front) <= 2:
            for ind in front:
                ind.crowding_dist = float('inf')
            return

        n_obj = len(front[0].fitness.values)

        for ind in front:
            ind.crowding_dist = 0

        for obj_idx in range(n_obj):
            front.sort(key=lambda x: x.fitness.values[obj_idx])

            f_min = front[0].fitness.values[obj_idx]
            f_max = front[-1].fitness.values[obj_idx]

            front[0].crowding_dist = float('inf')
            front[-1].crowding_dist = float('inf')

            if f_max - f_min > 0:
                for i in range(1, len(front) - 1):
                    distance = (front[i+1].fitness.values[obj_idx] -
                              front[i-1].fitness.values[obj_idx]) / (f_max - f_min)
                    front[i].crowding_dist += distance

    def selNSGA2_fast(self, individuals, k):
        fronts = self.fast_non_dominated_sort(individuals)

        selected = []
        for front in fronts:
            if len(selected) + len(front) <= k:
                selected.extend(front)
            else:
                self.calculate_crowding_distance(front)
                front.sort(key=lambda x: x.crowding_dist, reverse=True)
                remaining = k - len(selected)
                selected.extend(front[:remaining])
                break

        return selected

    def initialize_population(self):
        print("="*80)
        print("INITIALIZING POPULATION")
        print("="*80)
        population = []

        for lp_sol in self.lp_anchor_points:
            ind = creator.Individual(lp_sol.tolist())
            ind.constraint_violation = 0
            population.append(ind)

        remaining = self.POPULATION_SIZE - len(self.lp_anchor_points)
        for idx in range(remaining):
            individual = []
            for i in range(self.num_provinces):
                for j in range(self.num_projects):
                    for t in range(self.num_years):
                        max_val = self.max_volumes[i, j] / self.num_years
                        val = random.uniform(0, max_val * random.uniform(0.1, 0.3))
                        individual.append(val)

            individual = self.repair_individual_gentle(individual)
            ind = creator.Individual(individual)
            ind.constraint_violation = 0
            population.append(ind)

            if (idx + 1) % 1000 == 0:
                print(f"  {idx + 1}/{remaining}")

        print(f"✓ Initialized {len(population)} individuals")
        print("="*80 + "\n")
        return population

    def update_archive(self, population):
        feasible = [ind for ind in population if ind.constraint_violation == 0]

        if len(feasible) == 0:
            return

        combined = self.pareto_archive + feasible
        fronts = self.fast_non_dominated_sort(combined)
        if len(fronts) > 0:
            self.pareto_archive = fronts[0]

    def save_pareto_snapshot(self, generation):
        if generation in self.SNAPSHOT_GENERATIONS and len(self.pareto_archive) > 0:
            snapshot = []
            for ind in self.pareto_archive:
                ind_copy = {
                    'solution': list(ind),
                    'objectives': ind.fitness.values
                }
                snapshot.append(ind_copy)
            self.pareto_history[generation] = snapshot

    def save_pareto_to_csv(self, generation):
        if generation not in self.SNAPSHOT_GENERATIONS or len(self.pareto_archive) == 0:
            return

        data = []
        for idx, ind in enumerate(self.pareto_archive, 1):
            x = np.array(ind).reshape((self.num_provinces, self.num_projects, self.num_years))

            cost = np.sum(self.current_costs * x.sum(axis=0))

            total_water = sum(self.effectiveness[i, j] * x[i, j, :].sum()
                             for i in range(self.num_provinces)
                             for j in self.total_water_projects)

            low_risk_water = sum(self.effectiveness[i, j] * x[i, j, :].sum()
                                for i in range(self.num_provinces)
                                for j in self.low_risk_projects)

            data.append({
                'Generation': generation,
                'Point': idx,
                'Cost_TB_Rials': cost / 1e6,
                'TotalWater_M_m3': total_water / 1e6,
                'LowRisk_M_m3': low_risk_water / 1e6,
                'Combined_M_m3': (total_water + low_risk_water) / 1e6
            })

        df = pd.DataFrame(data)
        csv_filename = os.path.join(self.csv_output_dir, f"Pareto_Gen_{generation:03d}_S{self.scenario_to_run}.csv")
        df.to_csv(csv_filename, index=False)

        if generation % 50 == 0 or generation == 0 or generation == self.MAX_GENERATIONS:
            print(f"  → CSV: Pareto_Gen_{generation:03d} ({len(data)} points)")

    def run_optimization(self):
        print("="*80)
        print("RUNNING AUTO-MULTICORE GENETIC ALGORITHM")
        print("="*80)
        print(f"Using {self.N_CORES} CPU cores for parallel evaluation")
        print("="*80 + "\n")

        if hasattr(creator, "FitnessMulti"):
            del creator.FitnessMulti
        if hasattr(creator, "Individual"):
            del creator.Individual

        creator.create("FitnessMulti", base.Fitness, weights=(-1.0, -1.0, -1.0))
        creator.create("Individual", list, fitness=creator.FitnessMulti)

        toolbox = base.Toolbox()
        toolbox.register("evaluate", self.evaluate_individual)
        toolbox.register("mate", tools.cxSimulatedBinaryBounded,
                        low=[0] * self.num_variables,
                        up=[self.max_volumes.max()] * self.num_variables,
                        eta=self.ETA_C)
        toolbox.register("mutate", tools.mutPolynomialBounded,
                        low=[0] * self.num_variables,
                        up=[self.max_volumes.max()] * self.num_variables,
                        eta=self.ETA_M, indpb=0.1)

        population = self.initialize_population()

        print(f"Evaluating initial population on {self.N_CORES} cores...")
        eval_start = time.time()

        try:
            with Pool(processes=self.N_CORES, initializer=_init_worker, initargs=(self,)) as pool:
                fitnesses = pool.map(_evaluate_individual_worker, population)
            eval_time = time.time() - eval_start
            print(f"✓ Initial evaluation completed in {eval_time:.2f}s")
        except Exception as e:
            print(f"⚠️ Multiprocessing error, falling back to sequential evaluation")
            print(f"   Error: {e}")
            fitnesses = [self.evaluate_individual(ind) for ind in population]
            eval_time = time.time() - eval_start
            print(f"✓ Initial evaluation completed in {eval_time:.2f}s (sequential)")

        for ind, fit in zip(population, fitnesses):
            ind.fitness.values = fit

        self.update_archive(population)
        self.save_pareto_snapshot(0)
        self.save_pareto_to_csv(0)

        print(f"Gen 0: Pareto = {len(self.pareto_archive)}\n")

        start_time = time.time()
        use_multiprocessing = True

        for gen in range(1, self.MAX_GENERATIONS + 1):
            offspring = self.selNSGA2_fast(population, len(population))
            offspring = [toolbox.clone(ind) for ind in offspring]

            for child1, child2 in zip(offspring[::2], offspring[1::2]):
                if random.random() < self.CROSSOVER_PROB:
                    toolbox.mate(child1, child2)
                    del child1.fitness.values
                    del child2.fitness.values

            for mutant in offspring:
                if random.random() < self.MUTATION_PROB:
                    toolbox.mutate(mutant)
                    del mutant.fitness.values

            for ind in offspring:
                if not ind.fitness.valid:
                    ind[:] = self.repair_individual_gentle(ind)

            invalid = [ind for ind in offspring if not ind.fitness.valid]
            if len(invalid) > 0:
                try:
                    if use_multiprocessing:
                        with Pool(processes=self.N_CORES, initializer=_init_worker, initargs=(self,)) as pool:
                            fitnesses = pool.map(_evaluate_individual_worker, invalid)
                    else:
                        fitnesses = [self.evaluate_individual(ind) for ind in invalid]
                except Exception as e:
                    if use_multiprocessing:
                        print(f"\n⚠️ Multiprocessing failed at Gen {gen}, switching to sequential")
                        use_multiprocessing = False
                    fitnesses = [self.evaluate_individual(ind) for ind in invalid]

                for ind, fit in zip(invalid, fitnesses):
                    ind.fitness.values = fit

            population[:] = offspring
            self.update_archive(population)
            self.save_pareto_snapshot(gen)
            self.save_pareto_to_csv(gen)

            elapsed = time.time() - start_time
            speed = gen / elapsed
            eta = (self.MAX_GENERATIONS - gen) / speed if speed > 0 else 0

            if gen % 10 == 0 or gen == self.MAX_GENERATIONS:
                mode = f"{self.N_CORES} cores" if use_multiprocessing else "sequential"
                print(f"Gen {gen:3d}/{self.MAX_GENERATIONS} | Pareto: {len(self.pareto_archive):4d} | "
                      f"Speed: {speed:.4f} gen/s ({elapsed/gen:.1f} s/gen) | "
                      f"ETA: {eta/60:.1f} min | Mode: {mode}")

        elapsed = time.time() - start_time
        print(f"\n{'='*80}")
        print(f"✓ OPTIMIZATION COMPLETE")
        print(f"{'='*80}")
        print(f"Time: {elapsed:.2f}s ({elapsed/60:.2f} min)")
        print(f"Speed: {self.MAX_GENERATIONS/elapsed:.4f} gen/s")
        print(f"Mode: {'Multiprocessing' if use_multiprocessing else 'Sequential'}")
        print(f"Final Pareto: {len(self.pareto_archive)} points")
        print(f"CSV files: {len(self.SNAPSHOT_GENERATIONS)} in {self.csv_output_dir}/")
        print(f"{'='*80}\n")

        return self.pareto_archive

    def check_feasibility(self, pareto_front):
        """Diagnostic only: re-computes the constraint violation of the final
        archive in the main process (does not change any result)."""
        viol = [self.calculate_violations(ind) for ind in pareto_front]
        n_bad = sum(1 for v in viol if v > 1e-6)
        print("="*80)
        print("FEASIBILITY CHECK OF THE FINAL PARETO SET (diagnostic)")
        print("="*80)
        print(f"Points with violation > 1e-6: {n_bad} of {len(viol)}")
        print(f"Maximum violation: {max(viol):.6g}")
        print("="*80 + "\n")

    def plot_static_matplotlib(self):
        print("="*80)
        print("CREATING VISUALIZATION")
        print("="*80)

        fig = plt.figure(figsize=(18, 14))
        ax = fig.add_subplot(111, projection='3d')

        generations = sorted(self.pareto_history.keys())
        cmap = plt.get_cmap('rainbow', len(generations))

        for idx, gen in enumerate(generations):
            snapshot = self.pareto_history[gen]

            if len(snapshot) == 0:
                continue

            costs = []
            total_waters = []
            low_risk_waters = []

            for ind_data in snapshot:
                cost = ind_data['objectives'][0] / 1e6
                total_water = -ind_data['objectives'][1] / 1e6
                low_risk_water = -ind_data['objectives'][2] / 1e6

                costs.append(cost)
                total_waters.append(total_water)
                low_risk_waters.append(low_risk_water)

            if len(costs) > 1:
                min_cost, max_cost = min(costs), max(costs)
                if max_cost > min_cost:
                    norm_costs = [(c - min_cost) / (max_cost - min_cost) for c in costs]
                else:
                    norm_costs = [0.5] * len(costs)
            else:
                norm_costs = [0.5]

            base_color = cmap(idx)
            point_colors = []
            for nc in norm_costs:
                intensity = 0.3 + 0.7 * nc
                point_colors.append((base_color[0]*intensity, base_color[1]*intensity,
                                   base_color[2]*intensity, 0.7))

            ax.scatter(costs, total_waters, low_risk_waters,
                      c=point_colors, s=30, edgecolors='k', linewidth=0.3,
                      label=f'Gen {gen} ({len(costs)} pts)')

        ax.set_xlabel('Cost (TB Rials)', fontsize=13, labelpad=10)
        ax.set_ylabel('Total Water (M m³)', fontsize=13, labelpad=10)
        ax.set_zlabel('Low-Risk Water (M m³)', fontsize=13, labelpad=10)
        ax.set_title(f'Pareto Evolution - {self.N_CORES} Cores\n{self.scenario_names[self.scenario_to_run]}',
                    fontsize=15, pad=20, fontweight='bold')

        ax.legend(loc='upper left', fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        png_file = os.path.join(OUTPUT_DIR, f"ParetoVisualization_S{self.scenario_to_run}_{timestamp}.png")
        plt.savefig(png_file, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"✓ Visualization: {png_file}")
        print("="*80 + "\n")

        return png_file

    def save_results(self, pareto_front):
        print("="*80)
        print("SAVING FINAL RESULTS")
        print("="*80)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = os.path.join(OUTPUT_DIR, f"FinalResults_S{self.scenario_to_run}_{timestamp}")
        os.makedirs(output_dir, exist_ok=True)

        summary = []
        for idx, ind in enumerate(pareto_front, 1):
            x = np.array(ind).reshape((self.num_provinces, self.num_projects, self.num_years))

            cost = np.sum(self.current_costs * x.sum(axis=0))

            total_water = sum(self.effectiveness[i, j] * x[i, j, :].sum()
                             for i in range(self.num_provinces)
                             for j in self.total_water_projects)

            low_risk_water = sum(self.effectiveness[i, j] * x[i, j, :].sum()
                                for i in range(self.num_provinces)
                                for j in self.low_risk_projects)

            summary.append({
                'Point': idx,
                'Cost_TB': cost / 1e6,
                'TotalWater_M_m3': total_water / 1e6,
                'LowRisk_M_m3': low_risk_water / 1e6
            })

        excel_file = os.path.join(output_dir, f"FinalPareto_S{self.scenario_to_run}.xlsx")

        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            pd.DataFrame(summary).to_excel(writer, sheet_name='Summary', index=False)

            for idx, ind in enumerate(pareto_front, 1):
                x = np.array(ind).reshape((self.num_provinces, self.num_projects, self.num_years))

                details = []
                for i in range(self.num_provinces):
                    for j in range(self.num_projects):
                        for t in range(self.num_years):
                            if x[i, j, t] > 0.01:
                                details.append({
                                    'Province': i + 1,
                                    'Project_ID': j,
                                    'Project': self.project_names[j],
                                    'Year': t,
                                    'Volume': x[i, j, t],
                                    'Cost_M_Rials': self.current_costs[j, t] * x[i, j, t] / 1e3,
                                    'Water_M_m3': self.effectiveness[i, j] * x[i, j, t] / 1e6
                                })

                if details:
                    pd.DataFrame(details).to_excel(writer, sheet_name=f'Point_{idx}', index=False)

                if idx % 10 == 0:
                    print(f"  Written {idx}/{len(pareto_front)}")

        print(f"✓ Excel: {excel_file}")
        print(f"✓ Directory: {output_dir}")
        print("="*80 + "\n")

        return output_dir

def main():
    print("\n" + "="*80)
    print("WATER OPTIMIZATION - AUTO-MULTICORE VERSION (FIXED)")
    print("="*80)
    print(f"Input folder : {INPUT_DIR}")
    print(f"Output folder: {OUTPUT_DIR}")

    print("\nScenarios:")
    for i in range(1, 9):
        budget = "40%" if i <= 4 else "50%"
        cost_num = ((i-1) % 4) + 1
        print(f"  {i}. Budget {budget} - Cost {cost_num}")

    try:
        scenario = int(input("\nScenario (1-8): "))
        if scenario < 1 or scenario > 8:
            print("Invalid scenario!")
            return
    except:
        print("Invalid input!")
        return

    try:
        pop_size = int(input("Population (default 9000): ") or "9000")
    except:
        pop_size = 9000

    try:
        max_gen = int(input("Generations (default 50): ") or "50")
    except:
        max_gen = 50

    print(f"\nSnapshot generations (comma-separated, e.g., 0,5,10,15,20,25,30,35,40,45,50)")
    print(f"Press Enter for default (0,10,20,30,40,42,44,46,48 and the last generation)")
    snapshot_input = input("Snapshots: ").strip()

    if snapshot_input:
        try:
            snapshot_gens = [int(x.strip()) for x in snapshot_input.split(',')]
            snapshot_gens = sorted(set(snapshot_gens))
        except:
            print("Invalid input, using default")
            snapshot_gens = None
    else:
        snapshot_gens = None

    optimizer = WaterOptimizerAutoCore(
        scenario_to_run=scenario,
        population_size=pop_size,
        max_generations=max_gen,
        snapshot_generations=snapshot_gens
    )

    pareto_front = optimizer.run_optimization()

    if len(pareto_front) == 0:
        print("\n✗ No feasible solutions!")
        return

    # the figure must never stop the final results from being saved
    try:
        png_file = optimizer.plot_static_matplotlib()
    except Exception as e:
        png_file = "(not created)"
        print(f"⚠️ Visualization failed, continuing: {e}")

    output_dir = optimizer.save_results(pareto_front)

    try:
        optimizer.check_feasibility(pareto_front)
    except Exception as e:
        print(f"⚠️ Feasibility check failed: {e}")

    print("="*80)
    print("✓ COMPLETE!")
    print("="*80)
    print(f"System: {platform.system()}")
    print(f"Cores Available: {cpu_count()}")
    print(f"Cores Used: {optimizer.N_CORES}")
    print(f"Final Pareto: {len(pareto_front)} points")
    print(f"CSV files: {optimizer.csv_output_dir}/")
    print(f"Visualization: {png_file}")
    print(f"Final Excel: {output_dir}/")
    print("="*80)

if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    main()